﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        double ttoal = 0;

        double tt1 = Convert.ToDouble(T1.SelectedValue);
        double tt2 = Convert.ToDouble(T2.Text);
        double tt3 = Convert.ToDouble(T3.Text);
        double aa1 = Convert.ToDouble(a1.Text);
        double aa2 = Convert.ToDouble(a2.Text);
        double aa3 = Convert.ToDouble(a3.Text);

        if (C1.Checked)
            ttoal += tt1 * aa1;
        if (C2.Checked)
            ttoal += tt2 * aa2;
        if (C3.Checked)
            ttoal += tt3 * aa3;

        s1.Text = Convert.ToString(ttoal);

        if (R1.SelectedValue == "1")
            L1.Text = R1.SelectedItem.Text;
        if (R1.SelectedValue == "5")
            L1.Text = R1.SelectedItem.Text;
        if (R1.SelectedValue == "7")
            L1.Text = R1.SelectedItem.Text;
        if (R1.SelectedValue == "0")
            L1.Text = R1.SelectedItem.Text;
    }
}